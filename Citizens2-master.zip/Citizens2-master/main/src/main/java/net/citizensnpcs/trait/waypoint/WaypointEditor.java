package net.citizensnpcs.trait.waypoint;

import net.citizensnpcs.editor.Editor;

public abstract class WaypointEditor extends Editor {
    public Waypoint getCurrentWaypoint() {
        return null;
    }
}